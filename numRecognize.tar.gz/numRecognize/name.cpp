#include<iostream>
#include<opencv2/opencv.hpp>
using namespace std;
using namespace cv;

string to_string(int &x)
{
    stringstream ss;
    string y;
    ss<<x;
    ss>>y;
    return y;
}

int main()
{
    ofstream outfile;    //文件名准备输入打文件夹
    outfile.open("ImageName.txt");
    for(int i=1; i<=100; i++)
    {
        outfile<<"numRecognize/"+to_string(i)+".png"<<endl;
    }
    return 0;
}
